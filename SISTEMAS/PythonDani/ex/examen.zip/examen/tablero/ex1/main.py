
from ejercicios.examen.tablero.tablero import Tablero

tablero = Tablero("Adrian")
tablero.generar_aleatorios_uno()
tablero.graficar_trayectoria()

