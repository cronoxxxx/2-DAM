
from ejercicios.examen.tablero.tablero import Tablero


tablero = Tablero("Adrian2")
tablero.generar_aleatorios_dos()
tablero.graficar_trayectoria()
