
from robot import Robot

robot = Robot()
robot.mueve("AADAIADDRR")
robot.graficar_movimientos()
