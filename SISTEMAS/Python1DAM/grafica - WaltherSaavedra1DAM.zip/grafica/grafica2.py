from tkinter import *
from PIL import ImageTk, Image
import random

def escribe_fichero(preguntarespuesta):
    #crear fichero
    fichero = open("preguntasrespuestas.txt","a")
    #escribir en el fichero
    fichero.write(preguntarespuesta+"\n")
    #cerrar el fichero
    fichero.close()

def responde_graba(pr):
    respuestas = ["Si","No","Probablemente","No estoy muy seguro", "Totalmente cierto","Ten por seguro que si", "Eso nunca","Daro por hecho"]
    query = textbox.get()
    respuesta = random.choice(respuestas)
    pr = "Usted pregunto: "+ query + " Respuesta: "+ respuesta
    #Mostramos resultado en el label
    preview.config(text=pr)
    escribe_fichero(pr)

ventana = Tk()
ventana.title("Buscador")

# Load an image
img = ImageTk.PhotoImage(Image.open("grafica/negro.jpg"))
panel = Label(ventana, image=img)
panel.pack(side="bottom", fill="both", expand="yes")

textbox = Entry(ventana)
textbox.pack()

preview = Label(ventana)
preview.pack()

boton = Button(ventana, text="Buscar", command=lambda: responde_graba(preview))
boton.pack()

ventana.mainloop()