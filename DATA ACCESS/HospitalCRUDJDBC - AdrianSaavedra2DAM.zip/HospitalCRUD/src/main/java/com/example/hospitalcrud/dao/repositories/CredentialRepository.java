package com.example.hospitalcrud.dao.repositories;

import com.example.hospitalcrud.dao.model.Credential;

public interface CredentialRepository {
    Credential get(Credential credential);
}
