package com.example.hospitalcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalCrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
