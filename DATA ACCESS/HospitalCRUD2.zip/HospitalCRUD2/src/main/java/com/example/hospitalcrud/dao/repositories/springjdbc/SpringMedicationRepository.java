package com.example.hospitalcrud.dao.repositories.springjdbc;

import com.example.hospitalcrud.dao.mappers.spring.MedRecordRowMapper;
import com.example.hospitalcrud.dao.model.MedRecord;
import com.example.hospitalcrud.dao.model.Medication;
import com.example.hospitalcrud.dao.repositories.MedicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Profile("files")
public class SpringMedicationRepository implements MedicationRepository {
    @Autowired
    private JdbcClient jdbcClient;

    @Override
    public List<Medication> findByRecordId(int recordId) {
        return jdbcClient.sql("SELECT * FROM prescribed_medications WHERE record_id = ?")
                .param(recordId)
                .query((rs, rowNum) -> Medication.builder().medicationName(rs.getString("medication_name")).build())
                .list();
    }

    @Override
    @Transactional
    public void addMedication(int recordId, Medication medication) {
        jdbcClient.sql("INSERT INTO prescribed_medications (record_id, medication_name) VALUES (?, ?)")
                .param(recordId)
                .param(medication.getMedicationName())
                .update();
    }

    @Override
    public void deleteMedicationsByRecordId(int recordId) {
        jdbcClient.sql("DELETE FROM prescribed_medications WHERE record_id = ?")
                .param(recordId)
                .update();
    }

    @Override
    public void deleteMedicationsByPatientId(int patientId) {
        jdbcClient.sql("DELETE FROM prescribed_medications WHERE record_id IN (SELECT record_id FROM medical_records WHERE patient_id = ?)")
                .param(patientId)
                .update();
    }


}
