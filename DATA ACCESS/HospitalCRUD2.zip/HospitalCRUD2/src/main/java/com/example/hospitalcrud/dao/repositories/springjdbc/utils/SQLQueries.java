package com.example.hospitalcrud.dao.repositories.springjdbc.utils;

public class SQLQueries {
    public static final String GET_ALL_PATIENTS = "SELECT * FROM patients";
    public static final String ADD_PATIENT = "INSERT INTO patients (name, date_of_birth, phone) VALUES (?, ?, ?)";
    public static final String UPDATE_PATIENT = "UPDATE patients SET name = ?, date_of_birth = ?, phone = ? WHERE patient_id = ?";
    public static final String DELETE_PATIENT = "DELETE FROM patients WHERE patient_id = ?";
    public static final String GET_ALL_APPOINTMENTS = "SELECT * FROM appointments";
    public static final String DELETE_APPOINTMENTS_BY_PATIENT_ID = "DELETE FROM appointments WHERE patient_id = ?";
    public static final String GET_CREDENTIALS_BY_USERNAME = "SELECT * FROM user_login WHERE username = ?";
    public static final String ADD_CREDENTIALS = "INSERT INTO user_login (username, password, patient_id) VALUES (?, ?, ?)";
    public static final String DELETE_CREDENTIALS_BY_PATIENT_ID = "DELETE FROM user_login WHERE patient_id = ?";
    public static final String GET_CREDENTIALS_BY_PATIENT_ID = "SELECT * FROM user_login WHERE patient_id = ?";
    public static final String GET_ALL_MEDICAL_RECORDS = "SELECT * FROM medical_records";
    public static final String ADD_MEDICAL_RECORD = "INSERT INTO medical_records (patient_id, doctor_id, diagnosis, admission_date) VALUES (?, ?, ?, ?)";
    public static final String UPDATE_MEDICAL_RECORD = "UPDATE medical_records SET diagnosis = ?, admission_date = ?, doctor_id = ? WHERE record_id = ?";
    public static final String DELETE_MEDICAL_RECORD = "DELETE FROM medical_records WHERE record_id = ?";
}
