package com.example.hospitalcrud.dao.repositories.springjdbc;

import com.example.hospitalcrud.dao.mappers.spring.MedRecordRowMapper;
import com.example.hospitalcrud.dao.model.MedRecord;
import com.example.hospitalcrud.dao.model.Medication;
import com.example.hospitalcrud.dao.repositories.MedRecordRepository;
import com.example.hospitalcrud.dao.repositories.MedicationRepository;
import com.example.hospitalcrud.dao.repositories.springjdbc.utils.SQLQueries;
import com.example.hospitalcrud.domain.errors.ForeignKeyConstraintError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.util.List;
import java.util.Objects;

@Repository
@Profile("files")
public class SpringMedRecordRepository implements MedRecordRepository {
    @Autowired
    private JdbcClient jdbcClient;
    private final MedRecordRowMapper medRecordRowMapper;
    private final MedicationRepository medicationRepository;

    public SpringMedRecordRepository(MedRecordRowMapper medRecordRowMapper, MedicationRepository medicationRepository) {
        this.medRecordRowMapper = medRecordRowMapper;
        this.medicationRepository = medicationRepository;
    }

    @Override
    public List<MedRecord> findAll() {
        List<MedRecord> medRecords = jdbcClient.sql(SQLQueries.GET_ALL_MEDICAL_RECORDS)
                .query(medRecordRowMapper)
                .list();

        for (MedRecord medRecord : medRecords) {
            List<Medication> medications = medicationRepository.findByRecordId(medRecord.getId());
            medRecord.setMedications(medications);
        }

        return medRecords;
    }

    @Override
    @Transactional
    public int add(MedRecord medRecord) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcClient.sql(SQLQueries.ADD_MEDICAL_RECORD)
                .param(medRecord.getIdPatient())
                .param(medRecord.getIdDoctor())
                .param(medRecord.getDiagnosis())
                .param(Date.valueOf(medRecord.getDate()))
                .update(keyHolder);

        int newId = Objects.requireNonNull(keyHolder.getKey(), "Error creating medical record").intValue();
        for (Medication medication : medRecord.getMedications()) {
            medicationRepository.addMedication(newId, medication);
        }
        return newId;
    }

    @Override
    @Transactional
    public void update(MedRecord medRecord) {
        int affectedRows = jdbcClient.sql(SQLQueries.UPDATE_MEDICAL_RECORD)
                .param(medRecord.getDiagnosis())
                .param(Date.valueOf(medRecord.getDate()))
                .param(medRecord.getIdDoctor())
                .param(medRecord.getId())
                .update();

        if (affectedRows == 0) {
            throw new ForeignKeyConstraintError("Updating medical record failed, no rows affected.");
        }

        medicationRepository.deleteMedicationsByRecordId(medRecord.getId());

        for (Medication medication : medRecord.getMedications()) {
            medicationRepository.addMedication(medRecord.getId(), medication);
        }
    }

    @Override
    @Transactional
    public void delete(MedRecord medRecord) {
        medicationRepository.deleteMedicationsByRecordId(medRecord.getId());

        jdbcClient.sql(SQLQueries.DELETE_MEDICAL_RECORD)
                .param(medRecord.getId())
                .update();
    }

    @Override
    @Transactional
    public void delete(int patientId) {
        medicationRepository.deleteMedicationsByPatientId(patientId);

        jdbcClient.sql("DELETE FROM medical_records WHERE patient_id = ?")
                .param(patientId)
                .update();
    }



    @Override
    public List<MedRecord> findByPatientId(int patientId) {
        List<MedRecord> medRecords = jdbcClient.sql("SELECT * FROM medical_records WHERE patient_id = ?")
                .param(patientId)
                .query(medRecordRowMapper)
                .list();

        for (MedRecord medRecord : medRecords) {
            List<Medication> medications = medicationRepository.findByRecordId(medRecord.getId());
            medRecord.setMedications(medications);
        }

        return medRecords;
    }
}
