package com.example.hospitalcrud.dao.repositories.springjdbc;

import com.example.hospitalcrud.dao.mappers.spring.PatientRowMapper;
import com.example.hospitalcrud.dao.model.Credential;
import com.example.hospitalcrud.dao.model.MedRecord;
import com.example.hospitalcrud.dao.model.Patient;
import com.example.hospitalcrud.dao.repositories.*;
import com.example.hospitalcrud.domain.errors.ForeignKeyConstraintError;
import com.example.hospitalcrud.domain.errors.PatientHasMedicalRecordsException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import com.example.hospitalcrud.dao.repositories.springjdbc.utils.SQLQueries;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Repository
@Profile("files")
public class SpringPatientRepository implements PatientRepository {
    @Autowired
    private JdbcClient jdbcClient;
    private final PatientRowMapper patientRowMapper;
    private final CredentialRepository credentialRepository;
    private final PaymentRepository paymentRepository;
    private final MedRecordRepository medRecordRepository;
    private final AppointmentRepository appointmentRepository;

    public SpringPatientRepository(PatientRowMapper patientRowMapper,
                                   CredentialRepository credentialRepository,
                                   PaymentRepository paymentRepository, MedRecordRepository medRecordRepository, AppointmentRepository appointmentRepository) {
        this.medRecordRepository = medRecordRepository;
        this.patientRowMapper = patientRowMapper;
        this.credentialRepository = credentialRepository;
        this.paymentRepository = paymentRepository;
        this.appointmentRepository = appointmentRepository;
    }

    @Override
    public List<Patient> getAll() {
        List<Patient> patients = jdbcClient.sql(SQLQueries.GET_ALL_PATIENTS)
                .query(patientRowMapper)
                .list();

        for (Patient patient : patients) {
            Credential credential = credentialRepository.getByPatientId(patient.getId());
            patient.setCredential(credential);
        }

        return patients;
    }

    @Override
    @Transactional
    public int add(Patient patient) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcClient.sql(SQLQueries.ADD_PATIENT)
                .param(patient.getName())
                .param(patient.getBirthday())
                .param(patient.getPhone())
                .update(keyHolder);
        int newId = Objects.requireNonNull(keyHolder.getKey(), "Error creating patient").intValue();
        patient.setId(newId);
        patient.getCredential().setPatient_id(newId);
        credentialRepository.add(patient.getCredential());
        return newId;
    }

    @Override
    @Transactional
    public void delete(int id, boolean confirm) {
        if (!confirm) {
            List<MedRecord> medRecords = medRecordRepository.findByPatientId(id);
            if (!medRecords.isEmpty()) {
                throw new ForeignKeyConstraintError("The patient has medical records. Are you sure you want to delete it?");
            }
        }
        medRecordRepository.delete(id);
        appointmentRepository.delete(id);
        paymentRepository.delete(id);
        credentialRepository.delete(id);

        int affectedRows = jdbcClient.sql(SQLQueries.DELETE_PATIENT)
                .param(id)
                .update();

        if (affectedRows == 0) {
            throw new ForeignKeyConstraintError("Deleting patient failed, no rows affected.");
        }
    }

    @Override
    public void update(Patient patient) {
        int affectedRows = jdbcClient.sql(SQLQueries.UPDATE_PATIENT)
                .param(patient.getName())
                .param(patient.getBirthday())
                .param(patient.getPhone())
                .param(patient.getId())
                .update();

        if (affectedRows == 0) {
            throw new ForeignKeyConstraintError("Updating patient failed, no rows affected.");
        }
    }
}
