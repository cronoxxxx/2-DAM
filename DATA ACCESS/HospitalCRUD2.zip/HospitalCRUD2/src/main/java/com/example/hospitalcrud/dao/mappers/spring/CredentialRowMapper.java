package com.example.hospitalcrud.dao.mappers.spring;

import com.example.hospitalcrud.dao.model.Credential;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import java.sql.ResultSet;
import java.sql.SQLException;

@Component
@Profile("files")
public class CredentialRowMapper implements RowMapper<Credential> {
    @Override
    public Credential mapRow(ResultSet rs, int rowNum) throws SQLException {
        Credential credential = new Credential();
        credential.setUserName(rs.getString("username"));
        credential.setPassword(rs.getString("password"));
        credential.setPatient_id(rs.getInt("patient_id"));
        return credential;
    }
}