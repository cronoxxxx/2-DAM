package com.example.hospitalcrud.domain.services;

import com.example.hospitalcrud.dao.model.Credential;
import com.example.hospitalcrud.dao.model.MedRecord;
import com.example.hospitalcrud.dao.model.Patient;
import com.example.hospitalcrud.dao.model.Payment;
import com.example.hospitalcrud.dao.repositories.AppointmentRepository;
import com.example.hospitalcrud.dao.repositories.MedRecordRepository;
import com.example.hospitalcrud.dao.repositories.PatientRepository;
import com.example.hospitalcrud.dao.repositories.PaymentRepository;
import com.example.hospitalcrud.dao.repositories.jdbc.JDBCPaymentRepository;
import com.example.hospitalcrud.domain.errors.ForeignKeyConstraintError;
import com.example.hospitalcrud.domain.errors.PatientHasMedicalRecordsException;
import com.example.hospitalcrud.domain.model.PatientUI;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Service
public class PatientService {
    private final PatientRepository patientRepository;
    private final PaymentRepository paymentRepository;

    public PatientService(PatientRepository patientRepository, PaymentRepository paymentRepository) {
        this.patientRepository = patientRepository;
        this.paymentRepository = paymentRepository;
    }

    public List<PatientUI> getPatients() {
        List<Patient> patients = patientRepository.getAll();
        List<Payment> payments = paymentRepository.getAllPayments();

        List<PatientUI> patientUIs = new ArrayList<>();
        for (Patient patient : patients) {
            int totalPaid = 0;
            for (Payment payment : payments) {
                if (payment.getPatient_id() == patient.getId()) {
                    totalPaid = payment.getTotal_paid();
                    break;
                }
            }

            PatientUI patientUI = new PatientUI(
                    patient.getId(),
                    totalPaid,
                    patient.getName(),
                    patient.getPhone(),
                    patient.getCredential() != null ? patient.getCredential().getUserName() : null,
                    null, // No incluimos la contraseña por razones de seguridad
                    patient.getBirthday()
            );
            patientUIs.add(patientUI);
        }

        return patientUIs;
    }

    public int addPatient(PatientUI patientUI) {
        Patient patient = new Patient(0, patientUI.getName(), patientUI.getPhone(), patientUI.getBirthDate());
        String username = patientUI.getUserName() != null ? patientUI.getUserName() : null;
        String password = patientUI.getPassword() != null ? patientUI.getPassword() : null;
        patient.setCredential(new Credential(username, password));
        return patientRepository.add(patient);
    }

    public void updatePatient(PatientUI patientUI) {
        Patient patient = new Patient(patientUI.getId(), patientUI.getName(), patientUI.getPhone(), patientUI.getBirthDate());
        String username = patientUI.getUserName() != null ? patientUI.getUserName() : null;
        String password = patientUI.getPassword() != null ? patientUI.getPassword() : null;
        patient.setCredential(new Credential(username, password));
        patientRepository.update(patient);
    }

    public void delete(int patientId, boolean confirm) {
            patientRepository.delete(patientId, confirm);
    }



}
