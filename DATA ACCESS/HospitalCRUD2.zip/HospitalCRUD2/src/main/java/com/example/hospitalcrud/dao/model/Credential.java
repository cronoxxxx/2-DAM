package com.example.hospitalcrud.dao.model;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter@Setter
@NoArgsConstructor
public class Credential {

    private String userName;
    private String password;
    private Integer patient_id;


    public Credential(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }


}
