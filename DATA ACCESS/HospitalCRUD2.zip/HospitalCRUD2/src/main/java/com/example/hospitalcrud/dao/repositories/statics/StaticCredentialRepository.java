package com.example.hospitalcrud.dao.repositories.statics;

import com.example.hospitalcrud.dao.model.Credential;
import com.example.hospitalcrud.dao.repositories.CredentialRepository;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Profile("inDevelopment")
@Repository
public class StaticCredentialRepository implements CredentialRepository {
    private final List<Credential> credentials = new ArrayList<>();

    public Credential get(Credential credential) {
        credentials.add(new Credential("root", "root"));
        return credentials.stream().filter(c -> c.getUserName().equals(credential.getUserName()) &&
                c.getPassword().equals(credential.getPassword())).findFirst().orElse(null);
    }

    @Override
    public Credential get(String username) {
        return null;
    }

    @Override
    public void add(Credential credential) {

    }

    @Override
    public Credential getByPatientId(int patientId) {
        return null;
    }

    @Override
    public void delete(int id) {

    }

}
