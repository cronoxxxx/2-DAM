package com.example.hospitalcrud.dao.repositories.springjdbc;

import com.example.hospitalcrud.dao.mappers.spring.CredentialRowMapper;
import com.example.hospitalcrud.dao.model.Credential;
import com.example.hospitalcrud.dao.repositories.CredentialRepository;
import com.example.hospitalcrud.dao.repositories.springjdbc.utils.SQLQueries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@Profile("files")
public class SpringCredentialRepository implements CredentialRepository {
    @Autowired
    private JdbcClient jdbcClient;
    private final CredentialRowMapper credentialRowMapper;

    public SpringCredentialRepository(CredentialRowMapper credentialRowMapper) {
        this.credentialRowMapper = credentialRowMapper;
    }

    @Override
    public Credential get(String username) {
        return jdbcClient.sql(SQLQueries.GET_CREDENTIALS_BY_USERNAME)
                .param(username)
                .query(credentialRowMapper)
                .optional()
                .orElse(null);
    }

    @Override
    public void add(Credential credential) {
        jdbcClient.sql(SQLQueries.ADD_CREDENTIALS)
                .param(credential.getUserName())
                .param(credential.getPassword())
                .param(credential.getPatient_id())
                .update();
    }

    @Override
    public void delete(int id) {
        jdbcClient.sql(SQLQueries.DELETE_CREDENTIALS_BY_PATIENT_ID)
                .param(id)
                .update();
    }

    @Override
    public Credential getByPatientId(int patientId) {
        return jdbcClient.sql(SQLQueries.GET_CREDENTIALS_BY_PATIENT_ID)
                .param(patientId)
                .query(credentialRowMapper)
                .optional()
                .orElse(null);
    }
}
