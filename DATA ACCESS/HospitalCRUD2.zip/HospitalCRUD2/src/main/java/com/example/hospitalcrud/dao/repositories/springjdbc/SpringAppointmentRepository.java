package com.example.hospitalcrud.dao.repositories.springjdbc;

import com.example.hospitalcrud.dao.repositories.AppointmentRepository;
import com.example.hospitalcrud.dao.repositories.springjdbc.utils.SQLQueries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Profile("files")
public class SpringAppointmentRepository implements AppointmentRepository {
    @Autowired
    private JdbcClient jdbcClient;



    @Override
    public void delete(int patientId) {
        jdbcClient.sql(SQLQueries.DELETE_APPOINTMENTS_BY_PATIENT_ID)
                .param(patientId)
                .update();
    }
}
