package com.example.hospitalcrud.dao.repositories.springjdbc;

import com.example.hospitalcrud.dao.model.Payment;
import com.example.hospitalcrud.dao.repositories.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Profile("files")
public class SpringPaymentRepository implements PaymentRepository {
    @Autowired
    private JdbcClient jdbcClient;

    @Override
    public List<Payment> getAllPayments() {
        return jdbcClient.sql("SELECT patient_id, COALESCE(SUM(amount), 0) as total_paid FROM patient_payments GROUP BY patient_id")
                .query((rs, rowNum) -> new Payment(rs.getInt("patient_id"), rs.getInt("total_paid")))
                .list();
    }

    @Override
    public void delete(int patientId) {
        jdbcClient.sql("DELETE FROM patient_payments WHERE patient_id = ?")
                .param(patientId)
                .update();
    }
}
