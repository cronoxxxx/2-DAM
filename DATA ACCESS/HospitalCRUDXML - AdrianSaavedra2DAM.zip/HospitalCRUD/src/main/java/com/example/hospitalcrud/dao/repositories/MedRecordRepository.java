package com.example.hospitalcrud.dao.repositories;

import com.example.hospitalcrud.dao.model.MedRecord;
import com.example.hospitalcrud.domain.model.MedRecordUI;

import java.util.List;

public interface MedRecordRepository {

    List<MedRecord> getAll();

    int add(MedRecord medRecord);

    void update(MedRecord medRecord);

    void deleteMedRecord(int id);
    void deleteMedRecordsForPatient(int patientId);
}
