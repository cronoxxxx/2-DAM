package com.example.hospitalcrud.dao.repositories.jpa.impl;

import com.example.hospitalcrud.dao.model.Credential;
import com.example.hospitalcrud.dao.repositories.CredentialRepository;
import com.example.hospitalcrud.dao.repositories.jpa.utils.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Repository;

@Log4j2
@Repository
public class JPACredentialRepository implements CredentialRepository {
    private final JPAUtil jpaUtil;
    private EntityManager em;

    public JPACredentialRepository(JPAUtil jpaUtil) {
        this.jpaUtil = jpaUtil;
    }

    @Override
    public Credential get(String username) {
        Credential credential = null;
        em = jpaUtil.getEntityManager();
        try {
            credential = em.createNamedQuery("Credential.findByUserName", Credential.class)
                    .setParameter("username", username)
                    .getSingleResult();
        } catch (NoResultException e) {
            log.error(e.getMessage(), e);
        } finally {
            if (em != null) em.close();
        }
        return credential;
    }


}
