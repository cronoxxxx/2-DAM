package com.example.hospitalcrud.dao.repositories.jpa.impl;

import com.example.hospitalcrud.dao.model.MedRecord;
import com.example.hospitalcrud.dao.model.Medication;
import com.example.hospitalcrud.dao.repositories.MedRecordRepository;
import com.example.hospitalcrud.dao.repositories.jpa.utils.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
@Log4j2
public class JPAMedRecordRepository implements MedRecordRepository {
    private final JPAUtil jpaUtil;

    public JPAMedRecordRepository(JPAUtil jpaUtil) {
        this.jpaUtil = jpaUtil;
    }

    @Override
    public List<MedRecord> findAll() {
        try (EntityManager em = jpaUtil.getEntityManager()) {
            return em.createNamedQuery("MedRecord.getAllWithMedications", MedRecord.class).getResultList();
        }
    }

    @Override
    public int add(MedRecord medRecord) {
        EntityManager em = jpaUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            for (Medication medication : medRecord.getMedications()) {
                medication.setMedRecord(medRecord);
            }
            em.persist(medRecord);
            tx.commit();
            return medRecord.getId();
        } catch (NoResultException e) {
            if (tx.isActive()) tx.rollback();
            log.error(e.getMessage(), e);
            return 0;
        } finally {
            em.close();
        }
    }


    @Override
    public void update(MedRecord medRecord) {
        EntityManager em = jpaUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            em.createNamedQuery("Medication.DeleteByRecordId")
                    .setParameter("medRecordId", medRecord.getId())
                    .executeUpdate();

            for (Medication medication : medRecord.getMedications()) {
                em.persist(medication);
            }

            tx.commit();
        } catch (NoResultException e) {
            if (tx.isActive()) tx.rollback();
            log.error(e.getMessage(), e);
        } finally {
            if (em != null) em.close();
        }
    }


    @Override
    public List<MedRecord> findByPatientId(int patientId) {
        EntityManager em = jpaUtil.getEntityManager();
        try {
            return em.createNamedQuery(
                            "MedRecord.findByPatientId", MedRecord.class)
                    .setParameter("patientId", patientId)
                    .getResultList();
        } finally {
            if (em != null) em.close();
        }
    }

    @Override
    public void delete(MedRecord medRecord) {
        EntityManager em = jpaUtil.getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            MedRecord managedRecord = em.find(MedRecord.class, medRecord.getId());
            if (managedRecord != null) {
                em.remove(managedRecord);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            log.error(e.getMessage(),e);
        } finally {
            em.close();
        }
    }


}
