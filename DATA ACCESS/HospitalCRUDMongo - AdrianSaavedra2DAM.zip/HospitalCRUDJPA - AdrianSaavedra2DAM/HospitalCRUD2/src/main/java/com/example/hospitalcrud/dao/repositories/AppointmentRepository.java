package com.example.hospitalcrud.dao.repositories;


import java.util.List;

public interface AppointmentRepository{

    void delete(int patientId);

}
