package com.example.hospitalcrud.dao.model;

public class Appointment {
}
