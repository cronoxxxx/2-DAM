package com.example.hospitalcrud.dao.repositories.jpa.impl;

import com.example.hospitalcrud.dao.repositories.AppointmentRepository;
import org.springframework.stereotype.Repository;

@Repository
public class JPAAppointmentRepository implements AppointmentRepository {
    @Override
    public void delete(int patientId) {

    }
}
