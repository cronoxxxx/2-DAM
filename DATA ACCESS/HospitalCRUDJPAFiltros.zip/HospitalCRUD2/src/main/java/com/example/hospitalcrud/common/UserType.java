package com.example.hospitalcrud.common;

public enum UserType {
    ADMIN,DOCTOR,PATIENT
}
