package com.example.hospitalcrud.common;

import lombok.AllArgsConstructor;
import lombok.Data;
@AllArgsConstructor
@Data
public class FetchType {
    private int id;
    private UserType type;
}
