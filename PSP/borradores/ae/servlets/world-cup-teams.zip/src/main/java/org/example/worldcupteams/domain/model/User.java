package org.example.worldcupteams.domain.model;

import lombok.Data;

@Data
public class User {
    private String name;
    private String password;
    private String role;
}

