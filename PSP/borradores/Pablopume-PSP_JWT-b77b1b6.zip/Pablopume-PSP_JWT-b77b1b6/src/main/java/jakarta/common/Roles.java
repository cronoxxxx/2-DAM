package jakarta.common;

public enum Roles {

    ADMIN, USER

}
