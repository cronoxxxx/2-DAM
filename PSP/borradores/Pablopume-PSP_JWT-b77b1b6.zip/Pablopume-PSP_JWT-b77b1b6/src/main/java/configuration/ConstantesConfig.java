package configuration;

public class ConstantesConfig {
    private ConstantesConfig() {
    }

    public static final String MYSQL_PROPERTIES_XML = "mysql-properties.xml";
}
