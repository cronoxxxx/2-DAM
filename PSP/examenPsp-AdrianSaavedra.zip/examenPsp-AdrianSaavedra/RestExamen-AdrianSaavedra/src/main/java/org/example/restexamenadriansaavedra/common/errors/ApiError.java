package org.example.restexamenadriansaavedra.common.errors;

public record ApiError(String message) {
}
