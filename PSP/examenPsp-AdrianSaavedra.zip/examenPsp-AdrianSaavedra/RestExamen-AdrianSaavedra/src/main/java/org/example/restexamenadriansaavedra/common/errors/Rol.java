package org.example.restexamenadriansaavedra.common.errors;

public class Rol extends RuntimeException{
    public Rol(String message) {
        super(message);
    }
}
