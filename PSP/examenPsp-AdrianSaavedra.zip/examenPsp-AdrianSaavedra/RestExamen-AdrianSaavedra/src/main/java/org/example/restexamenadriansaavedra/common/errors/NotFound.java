package org.example.restexamenadriansaavedra.common.errors;

public class NotFound extends RuntimeException{
    public NotFound(String message) {
        super(message);
    }
}
