package org.example.restexamenadriansaavedra.common.errors;

public class Invalid extends RuntimeException{
    public Invalid(String message) {
        super(message);
    }
}
