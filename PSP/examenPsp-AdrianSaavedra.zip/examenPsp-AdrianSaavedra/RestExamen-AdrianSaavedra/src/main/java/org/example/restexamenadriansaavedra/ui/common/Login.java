package org.example.restexamenadriansaavedra.ui.common;

import lombok.Data;

@Data
public class Login {
    private String username;
    private String password;
}
