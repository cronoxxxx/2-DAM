package org.example.restexamenadriansaavedra.common.errors;

public class CropNotAvailable extends RuntimeException{

    public CropNotAvailable(String message) {
        super(message);
    }
}
