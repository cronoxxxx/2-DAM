package org.example.restexamenadriansaavedra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestExamenAdrianSaavedraApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestExamenAdrianSaavedraApplication.class, args);
    }

}
