package com.example.buzonfxspring_adriansaavedra.domain.model;

import lombok.AllArgsConstructor;
import lombok.Data;
@AllArgsConstructor
@Data
public class MensajePrivadoUserClave {
    private String user;
    private String clave;
}
