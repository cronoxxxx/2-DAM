Usuarios:

- user ble pass ble
- user adrian pass adrian
- user adrian2 pass adrian2
- diego pass diego

Grupos:

- grupo publico pass publico
- grupo diegopublico pass diegopublico

Administradores grupos secretos:

- grupo secreto admin ble

