package org.example.loginspring_adriansaavedra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginSpringAdrianSaavedraApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoginSpringAdrianSaavedraApplication.class, args);
    }

    /*
    * dudas de como poner el permiso al usuario para que solo pueda acceder a sus jugadores favoritos, solo a su id y del resto no
    * como poner el permiso de que solo pueda acceder a sus jugadores favoritos
    * como mandar en un cuerpo dos menajes en el httprequest de la peticion y que funcione
    * */

}
