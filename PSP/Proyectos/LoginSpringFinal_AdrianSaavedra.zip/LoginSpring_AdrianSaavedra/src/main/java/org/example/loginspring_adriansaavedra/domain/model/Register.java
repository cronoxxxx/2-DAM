package org.example.loginspring_adriansaavedra.domain.model;

import lombok.Data;

@Data
public class Register {
    private String username;
    private String password;
    private String email;
}