package org.example.loginspring_adriansaavedra.common.errors;

public class PlayerValidatorException extends RuntimeException{
    public PlayerValidatorException(String message) {
        super(message);
    }
}
