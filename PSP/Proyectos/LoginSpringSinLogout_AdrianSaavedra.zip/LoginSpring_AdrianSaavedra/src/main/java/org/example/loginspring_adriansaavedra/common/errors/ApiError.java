package org.example.loginspring_adriansaavedra.common.errors;


public record ApiError(String message) {
}
