package org.example.loginspring_adriansaavedra.ui.utils;

import lombok.Data;

@Data
public class PlayerNameRequest {
    private String playerName;
}
