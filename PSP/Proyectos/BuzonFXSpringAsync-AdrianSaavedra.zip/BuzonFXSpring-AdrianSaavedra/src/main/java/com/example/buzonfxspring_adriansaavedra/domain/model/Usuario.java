package com.example.buzonfxspring_adriansaavedra.domain.model;

import lombok.*;

@Data
@AllArgsConstructor
public class Usuario {
    private String nombre;
}
