Usuarios:

- user ble pass ble
- user adrian pass adrian
- user adrian2 pass adrian2

Grupos:

- grupo publico pass publico

Administradores grupos secretos:

- grupo secreto admin ble