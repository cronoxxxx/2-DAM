package com.example.buzonfxspring_adriansaavedra.domain.errors;

public sealed interface ErrorApp
        permits ErrorAppDataBase, ErrorAppDatosNoValidos{}
