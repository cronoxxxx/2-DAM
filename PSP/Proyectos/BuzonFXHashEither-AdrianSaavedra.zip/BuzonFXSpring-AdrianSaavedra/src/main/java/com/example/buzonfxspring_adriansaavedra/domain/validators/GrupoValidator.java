package com.example.buzonfxspring_adriansaavedra.domain.validators;

import com.example.buzonfxspring_adriansaavedra.common.Constantes;
import com.example.buzonfxspring_adriansaavedra.domain.model.Grupo;
import io.vavr.control.Either;
import org.springframework.stereotype.Component;

@Component
public class GrupoValidator {
    public Either<String, Boolean> validateGrupo(Grupo grupo) {
        if (grupo.getNombre().isBlank()) {
            return Either.left(Constantes.CONTENIDO_ERROR_GRUPO_NO_ENCONTRADO);
        }
        if (grupo.getPassword().isBlank()) {
            return Either.left(Constantes.CONTENIDO_ERROR_GRUPO_VACIO);
        }
        return Either.right(true);
    }
}
