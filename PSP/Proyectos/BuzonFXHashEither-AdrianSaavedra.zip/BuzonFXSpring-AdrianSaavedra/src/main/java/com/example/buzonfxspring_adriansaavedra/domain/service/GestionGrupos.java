package com.example.buzonfxspring_adriansaavedra.domain.service;

import com.example.buzonfxspring_adriansaavedra.common.Constantes;
import com.example.buzonfxspring_adriansaavedra.dao.impl.DaoGruposImpl;
import com.example.buzonfxspring_adriansaavedra.domain.model.Grupo;
import com.example.buzonfxspring_adriansaavedra.domain.model.Usuario;
import com.example.buzonfxspring_adriansaavedra.domain.validators.GrupoValidator;
import io.vavr.control.Either;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GestionGrupos implements IGestionGrupos {
    private final DaoGruposImpl daoGrupos;
    private final GrupoValidator grupoValidator;
    private final PasswordEncoder passwordEncoder;

    public GestionGrupos(DaoGruposImpl daoGrupos, GrupoValidator grupoValidator, PasswordEncoder passwordEncoder) {
        this.daoGrupos = daoGrupos;
        this.grupoValidator = grupoValidator;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public Either<String, Boolean> actualizarGrupo(Grupo grupo) {
        return grupoValidator.validateGrupo(grupo)
                .flatMap(valid -> {
                    if (grupo.getPassword() != null && !grupo.getPassword().isEmpty()) {
                        grupo.setPassword(passwordEncoder.encode(grupo.getPassword()));
                    }
                    return daoGrupos.actualizarGrupo(grupo);
                })
                .mapLeft(error -> Constantes.GRUPO_NO_VALIDO);
    }


    @Override
    public Either<String, List<Grupo>> obtenerGrupos() {
        return daoGrupos.obtenerGrupos();
    }

    @Override
    public Either<String, Boolean> saveGrupos(List<Grupo> grupos) {
        return daoGrupos.saveGrupos(grupos);
    }

    @Override
    public Either<String, List<String>> obtenerGruposParaUsuario(String nombreUsuario, boolean publico) {
        return daoGrupos.obtenerGruposParaUsuario(nombreUsuario, publico);
    }

    @Override
    public Either<String, Grupo> obtenerGrupoPorNombre(String nombreGrupo) {
        return daoGrupos.obtenerGrupoPorNombre(nombreGrupo);
    }

    @Override
    public Either<String, Boolean> addGroup(Grupo grupo) {
        return grupoValidator.validateGrupo(grupo)
                .flatMap(valid -> {
                    if (grupo.getAdministrador() == null) {
                        return Either.left(Constantes.GRUPO_NO_VALIDO);
                    }
                    String pass = passwordEncoder.encode(grupo.getPassword());
                    grupo.setPassword(pass);
                    return obtenerGrupos().flatMap(grupos -> {
                        grupos.add(grupo);
                        return saveGrupos(grupos);
                    });
                })
                .mapLeft(error -> Constantes.GRUPO_NO_VALIDO);
    }

    @Override
    public Either<String, Grupo> ingresar(Grupo grupo) {
        return obtenerGrupos().flatMap(list -> {
            saveGrupos(list);
            return list.stream()
                    .filter(g -> g != null && g.getNombre() != null && g.getPassword() != null)
                    .filter(g -> g.getNombre().equals(grupo.getNombre()) && g.isPublico() == grupo.isPublico())
                    .findFirst()
                    .map(grupoEncontrado -> {
                        if (passwordEncoder.matches(grupo.getPassword(), grupoEncontrado.getPassword())) {
                            return daoGrupos.ingresar(grupoEncontrado);
                        } else {
                            return Either.<String, Grupo>left(Constantes.GRUPO_NO_VALIDO);
                        }
                    })
                    .orElseGet(() -> Either.left(Constantes.NO_HAY_GRUPO_ENCONTRADO));
        });
    }

    @Override
    public Either<String, Boolean> agregarMiembroGrupo(Grupo grupo, Usuario miembro) {
        return grupoValidator.validateGrupo(grupo)
                .flatMap(valid -> daoGrupos.agregarMiembroGrupo(grupo, miembro))
                .mapLeft(error -> Constantes.GRUPO_NO_VALIDO);
    }
}