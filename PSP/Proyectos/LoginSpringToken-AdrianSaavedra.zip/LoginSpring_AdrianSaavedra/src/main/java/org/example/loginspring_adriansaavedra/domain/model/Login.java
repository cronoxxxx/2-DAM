package org.example.loginspring_adriansaavedra.domain.model;

import lombok.Data;

@Data
public class Login {
    private String username;
    private String password;
}
