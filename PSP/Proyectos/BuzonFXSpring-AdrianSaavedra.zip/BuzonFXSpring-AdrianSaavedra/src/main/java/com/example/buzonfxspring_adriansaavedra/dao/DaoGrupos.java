package com.example.buzonfxspring_adriansaavedra.dao;

import com.example.buzonfxspring_adriansaavedra.domain.model.Grupo;
import com.example.buzonfxspring_adriansaavedra.domain.model.Usuario;

import java.util.List;

public interface DaoGrupos {



    boolean actualizarGrupo(Grupo grupo);

    List<Grupo> obtenerGrupos();

    boolean saveGrupos(List<Grupo> grupos);
    List<String> obtenerGruposParaUsuario(String nombreUsuario, boolean publico);

    Grupo obtenerGrupoPorNombre(String nombreGrupo);

    Grupo ingresar(Grupo grupo);

    boolean agregarMiembroGrupo(Grupo grupo, Usuario miembro);
}
