package org.example;

public class Constantes {
 public static final String NAME_SERVER ="GuessNumberServlet";
 public static final String VALUE_SERVER = "/GuessNumberServlet";
    public static final String GUESS = "guess";
    public static final String CONTADOR = "contador";
    public static final String NUMBER_TO_GUESS = "numberToGuess";
    public static final String LAST_GUESS = "lastGuess";
    public static final String GUESS_LOWER = "El numero es menor. Intenta nuevamente.";
    public static final String GUESS_HIGHER = "El numero es mayor. Intenta nuevamente.";
    public static final String WIN_MESSAGE = "Felicidades! Adivinaste el numero ";
    public static final String RETRY_MESSAGE = ".  Introduzca un numero si desea volver a empezar.";
    public static final String RETRY_MESSAGE_LOOSE = "Has perdido. Introduzca un numero si desea volver a empezar.";
    public static final String FELICIDADES = "Felicidades!";
    public static final String HAS_PERDIDO = "Has perdido.";
    public static final String INIT = "text/html";
    public static final String  INTRODUZCA_UN_NUMERO = "Introduzca un numero";
    public static final String HAS_REPETIDO_EL_NUMERO = "Has repetido el numero.";
}

