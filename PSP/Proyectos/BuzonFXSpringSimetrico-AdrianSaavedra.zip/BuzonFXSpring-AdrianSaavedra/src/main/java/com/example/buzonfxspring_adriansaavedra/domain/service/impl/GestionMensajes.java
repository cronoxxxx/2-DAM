package com.example.buzonfxspring_adriansaavedra.domain.service.impl;

import com.example.buzonfxspring_adriansaavedra.common.seguridad.EncriptacionAES;
import com.example.buzonfxspring_adriansaavedra.dao.impl.DaoMensajesImpl;
import com.example.buzonfxspring_adriansaavedra.domain.errors.ErrorApp;
import com.example.buzonfxspring_adriansaavedra.domain.model.Grupo;
import com.example.buzonfxspring_adriansaavedra.domain.model.Mensaje;
import com.example.buzonfxspring_adriansaavedra.domain.service.IGestionMensajes;
import io.vavr.control.Either;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class GestionMensajes implements IGestionMensajes {
    private final DaoMensajesImpl daoMensajes;
    private final EncriptacionAES encriptacion;

    public GestionMensajes(DaoMensajesImpl daoMensajes, EncriptacionAES encriptacion) {
        this.encriptacion = encriptacion;
        this.daoMensajes = daoMensajes;
    }


    @Override
    public Either<ErrorApp, List<Mensaje>> obtenerMensajesDeGrupo(Grupo grupo) {

        return daoMensajes.obtenerMensajesDeGrupo(grupo).map(this::desencriptarMensajes);
    }

    @Override
    public Either<ErrorApp, Boolean> addMensajes(Mensaje mensaje) {
        String contenidoDesencriptado = encriptacion.encriptar(mensaje.getTexto(),mensaje.getGroup());
        mensaje.setTexto(contenidoDesencriptado);
        return daoMensajes.addMensajes(mensaje);
    }

    private Mensaje desencriptarMensaje (Mensaje mensaje) {
        String contenidoDesencriptado = encriptacion.desencriptar(mensaje.getTexto(),mensaje.getGroup());
        mensaje.setTexto(contenidoDesencriptado);
        return mensaje;
    }

    private List<Mensaje> desencriptarMensajes (List<Mensaje> mensajes) {
        return mensajes.stream().map(this::desencriptarMensaje).toList();
    }
}
