package com.example.buzonfxspring_adriansaavedra.domain.service.impl;

import com.example.buzonfxspring_adriansaavedra.common.Constantes;
import com.example.buzonfxspring_adriansaavedra.dao.impl.DaoUsuariosImpl;
import com.example.buzonfxspring_adriansaavedra.domain.errors.ErrorApp;
import com.example.buzonfxspring_adriansaavedra.domain.errors.ErrorAppDatosNoValidos;
import com.example.buzonfxspring_adriansaavedra.domain.model.Usuario;
import com.example.buzonfxspring_adriansaavedra.domain.service.IGestionUsuarios;
import com.example.buzonfxspring_adriansaavedra.domain.validators.UserValidator;
import io.vavr.control.Either;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GestionUsuarios implements IGestionUsuarios {
    private final DaoUsuariosImpl dao;
    private final UserValidator userValidator;
    private final PasswordEncoder passwordEncoder;

    public GestionUsuarios(DaoUsuariosImpl dao, UserValidator userValidator, PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
        this.dao = dao;
        this.userValidator = userValidator;
    }

    @Override
    public Either<ErrorApp, Usuario> login(Usuario usuario) {
        return userValidator.validateUser(usuario)
                .flatMap(valid -> dao.buscarUsuarioPorNombre(usuario.getNombre()))
                .flatMap(usuarioEncontrado ->
                        passwordEncoder.matches(usuario.getPassword(), usuarioEncontrado.getPassword())
                                ? Either.right(usuarioEncontrado)
                                : Either.left(new ErrorAppDatosNoValidos(Constantes.USUARIO_NO_VALIDO))
                );
    }

    @Override
    public Either<ErrorApp, Boolean> addUsuario(Usuario usuario) {
        return userValidator.validateUser(usuario)
                .map(valid -> {
                    usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
                    return usuario;
                })
                .flatMap(dao::addUsuario);
    }

    @Override
    public Either<ErrorApp, Usuario> buscarUsuarioPorNombre(String nombre) {
        return dao.buscarUsuarioPorNombre(nombre);
    }

    @Override
    public Either<ErrorApp, List<Usuario>> buscarUsuariosPorNombres(List<String> nombres) {
        return dao.buscarUsuariosPorNombres(nombres);
    }
}