package com.example.buzonfxspring_adriansaavedra.domain.errors;

public enum ErrorAppDataBase implements ErrorApp {
    TIMEOUT,
    NO_CONNECTION
}
