package gui.pantallas.registro;

import lombok.Data;

@Data
public class RegistroState {
    private final boolean register;
    private final String error;
}
