package domain.modelo;

public interface Clonable<T> {
    T clonar();
}
