package domain.services;

import domain.modelo.ProductoPerecedero;

public interface ServicesProductosPerecederos {
    boolean productoCaducado(ProductoPerecedero perecedero);
}
