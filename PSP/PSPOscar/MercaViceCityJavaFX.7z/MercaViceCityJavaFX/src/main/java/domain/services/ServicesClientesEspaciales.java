package domain.services;

public interface ServicesClientesEspaciales {
    boolean scSetDescuentoClientesEspaciales(int porcentajeDescuento);
}
