package configuracion.common;

public class Constantes {

    public static final String PATH_JSON_CLIENTES = "pathJSONClientes";
    public static final String PATH_JSON_PRODUCTOS = "pathJSONProductos";

    private Constantes() {
    }

    public static final String CONFIG_YAML = "config.yaml";

}
