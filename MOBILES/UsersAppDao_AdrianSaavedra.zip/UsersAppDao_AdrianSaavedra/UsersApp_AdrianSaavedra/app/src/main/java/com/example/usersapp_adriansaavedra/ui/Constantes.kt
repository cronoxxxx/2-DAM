package com.example.usersapp_adriansaavedra.ui

object Constantes {
    const val ACCEDER = "Acceder"
    const val ERROR_API_CALL_FAILED = "Error API llamada fallida: "
    const val APP_DB = "app.db"

}