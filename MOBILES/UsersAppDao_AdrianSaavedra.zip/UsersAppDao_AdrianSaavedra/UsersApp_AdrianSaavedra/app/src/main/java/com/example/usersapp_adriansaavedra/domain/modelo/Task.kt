package com.example.usersapp_adriansaavedra.domain.modelo

data class Task(
    val userId: Int,
    val id: Int,
    val title: String,
    val completed: Boolean
)


