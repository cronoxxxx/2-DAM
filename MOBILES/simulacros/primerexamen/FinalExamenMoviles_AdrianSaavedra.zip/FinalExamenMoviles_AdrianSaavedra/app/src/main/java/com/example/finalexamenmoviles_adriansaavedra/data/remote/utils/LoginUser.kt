package com.example.finalexamenmoviles_adriansaavedra.data.remote.utils

data class LoginUser(val username: String = "", val password: String = "")