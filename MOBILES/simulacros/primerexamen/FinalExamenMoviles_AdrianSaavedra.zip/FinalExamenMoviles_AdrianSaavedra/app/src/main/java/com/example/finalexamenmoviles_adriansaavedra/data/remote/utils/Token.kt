package com.example.finalexamenmoviles_adriansaavedra.data.remote.utils

data class Token( val accessToken : String)
