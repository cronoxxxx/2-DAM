package com.example.finalexamenmoviles_adriansaavedra.domain.model

data class Raton(val nombre:String)