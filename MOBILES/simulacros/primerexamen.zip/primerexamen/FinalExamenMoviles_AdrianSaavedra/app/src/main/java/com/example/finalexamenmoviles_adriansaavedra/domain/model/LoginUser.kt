package com.example.finalexamenmoviles_adriansaavedra.domain.model

data class LoginUser(val username: String = "", val password: String = "")