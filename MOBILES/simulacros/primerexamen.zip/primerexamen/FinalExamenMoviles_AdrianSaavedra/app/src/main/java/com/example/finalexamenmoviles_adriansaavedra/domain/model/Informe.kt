package com.example.finalexamenmoviles_adriansaavedra.domain.model

data class Informe(
    val id: Int = 0,
    val nombre: String = "",
    val nivel: Int = 1
)