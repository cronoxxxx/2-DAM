package com.example.finalexamenmoviles_adriansaavedra.domain.model

data class Token( val accessToken : String)
