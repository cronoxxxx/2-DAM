package com.example.finalexamenmoviles_adriansaavedra.data.remote.utils

data class ApiError(val message: String)
