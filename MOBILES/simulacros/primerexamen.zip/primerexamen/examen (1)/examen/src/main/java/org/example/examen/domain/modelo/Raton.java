package org.example.examen.domain.modelo;

public record Raton(String nombre) {
}
