package org.example.examen.domain.modelo;

public record Token(String accessToken) {
}
