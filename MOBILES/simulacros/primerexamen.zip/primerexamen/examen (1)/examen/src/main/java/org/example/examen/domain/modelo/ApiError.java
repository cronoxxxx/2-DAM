package org.example.examen.domain.modelo;

public record ApiError(int codigo, String mensaje) {
}
