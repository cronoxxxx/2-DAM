package org.example.examen.domain.modelo;

public record Asignatura(
        String nombre,
        String codigo,
        int creditos,
        double nota
) {
}
