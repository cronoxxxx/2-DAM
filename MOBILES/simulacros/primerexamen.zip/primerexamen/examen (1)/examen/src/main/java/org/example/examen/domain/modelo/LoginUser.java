package org.example.examen.domain.modelo;

public record LoginUser(
        String username,
        String password
) {
}
