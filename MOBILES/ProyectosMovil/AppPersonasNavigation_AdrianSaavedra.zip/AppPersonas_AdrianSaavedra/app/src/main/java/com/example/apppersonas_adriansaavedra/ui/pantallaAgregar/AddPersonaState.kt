package com.example.apppersonas_adriansaavedra.ui.pantallaAgregar

import com.example.apppersonas_adriansaavedra.ui.common.UiEvent

data class AddPersonaState(
    val aviso: UiEvent? = null
)