package com.example.apppersonas_adriansaavedra.ui

object Constantes {
    const val PERSONA_AGREGADA= "Persona Agregada"
    const val NAVEGANDO_AL_FRAGMENT_PRINCIPAL = "Navegando al Fragment Principal"
    const val NAVEGANDO_AL_FRAGMENT_DE_AGREGAR_PERSONA= "Navegando al Fragment de Agregar Persona"
    const val PERSONA_ACTUALIZADA = "Persona Actualizada"
    const val PERSONA_ELIMINADA = "Persona Eliminada"
    const val OBTENIENDO_PERSONA_CON_ID = "Obteniendo Persona con ID "
    const val PERSONAS_OBTENIDAS = "Personas Obtenidas: "
    const val NAVEGANDO_AL_FRAGMENT_DE_PERSONA_CON_ID= "Navegando al Fragment de persona con ID "
    const val IMG_STEVE = "file:///android_asset/steve.png"
}