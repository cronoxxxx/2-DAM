package com.example.usersapp_adriansaavedra.ui

object Constantes {
    const val USUARIO_EN_BLANCO = "Usuario en blanco"
    const val ERROR_API_CALL_FAILED = "Error API llamada fallida: "
}