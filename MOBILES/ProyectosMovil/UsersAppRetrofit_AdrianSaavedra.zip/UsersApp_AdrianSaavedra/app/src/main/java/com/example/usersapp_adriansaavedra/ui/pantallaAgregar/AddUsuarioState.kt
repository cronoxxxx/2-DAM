package com.example.usersapp_adriansaavedra.ui.pantallaAgregar

import com.example.usersapp_adriansaavedra.ui.common.UiEvent

data class AddUsuarioState(
    val aviso : UiEvent?=null
)