package com.example.usersapp_adriansaavedra.data.remote.modelo

data class Address(
    val street: String,
    val city: String
)

