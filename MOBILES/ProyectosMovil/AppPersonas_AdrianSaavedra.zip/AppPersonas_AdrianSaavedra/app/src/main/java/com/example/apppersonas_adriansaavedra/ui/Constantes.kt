package com.example.apppersonas_adriansaavedra.ui

object Constantes {
    const val DEFAULT_VALUE_INT= -1
    const val ID = "id"
    const val MODO = "modo"
    const val MODO_AGREGAR = "agregar"
    const val IMG_STEVE = "file:///android_asset/steve.png"

}