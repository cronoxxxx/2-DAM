package com.example.playersapp_adriansaavedra.data.remote.utils

data class ApiError(val message: String)
