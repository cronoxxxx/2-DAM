package com.example.playersapp_adriansaavedra.data.remote.model

data class Login(val username: String = "", val password: String = "")