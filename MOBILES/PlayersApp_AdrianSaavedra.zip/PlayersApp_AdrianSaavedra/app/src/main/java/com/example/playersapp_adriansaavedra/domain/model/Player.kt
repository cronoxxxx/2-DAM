package com.example.playersapp_adriansaavedra.domain.model


data class Player(
    val id: Int,
    val name: String,
    val team: String,
    val country: String
)
