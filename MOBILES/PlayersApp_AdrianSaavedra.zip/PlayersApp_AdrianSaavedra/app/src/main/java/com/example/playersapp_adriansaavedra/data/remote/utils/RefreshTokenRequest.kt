package com.example.playersapp_adriansaavedra.data.remote.utils

data class RefreshTokenRequest(val refreshToken: String)