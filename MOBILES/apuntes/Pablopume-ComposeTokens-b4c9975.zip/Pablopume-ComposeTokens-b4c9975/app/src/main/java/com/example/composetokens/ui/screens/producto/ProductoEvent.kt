package com.example.composetokens.ui.screens.producto

sealed class ProductoEvent {
 data object GetProductos : ProductoEvent()

}