package com.example.composetokens.domain.model

data class Producto (
    val id: Long,
    val nombre: String,
    val precio: Double,
    val stock: Int

)