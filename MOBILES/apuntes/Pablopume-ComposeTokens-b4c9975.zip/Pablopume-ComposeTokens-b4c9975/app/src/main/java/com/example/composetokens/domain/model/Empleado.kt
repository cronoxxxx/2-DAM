package com.example.composetokens.domain.model

data class Empleado(
    val id: Long,
    val nombre: String,
    val apellido: String,
    val cargo: String,

    val tiendaId: Long
)