package com.example.composetokens

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TokensApp: Application(){
}