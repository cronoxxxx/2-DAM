package com.example.composetokens.domain.model

data class Cliente(
    val id: Long,
    val nombre: String?,
    val email: String?,
)