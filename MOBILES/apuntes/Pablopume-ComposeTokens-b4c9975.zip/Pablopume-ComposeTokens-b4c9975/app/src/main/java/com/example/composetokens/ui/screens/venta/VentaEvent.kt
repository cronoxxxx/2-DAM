package com.example.composetokens.ui.screens.venta

sealed class VentaEvent {
 data object GetVentas : VentaEvent()

}