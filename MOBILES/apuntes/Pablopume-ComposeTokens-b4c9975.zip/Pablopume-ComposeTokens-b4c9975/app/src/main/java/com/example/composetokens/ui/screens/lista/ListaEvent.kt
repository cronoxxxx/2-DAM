package com.example.composetokens.ui.screens.lista

sealed class ListaEvent {
 data object GetTiendas : ListaEvent()

}