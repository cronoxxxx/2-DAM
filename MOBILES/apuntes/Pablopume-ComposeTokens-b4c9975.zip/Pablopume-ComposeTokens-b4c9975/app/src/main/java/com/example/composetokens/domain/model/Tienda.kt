package com.example.composetokens.domain.model

data class Tienda(
    val id: Long,
    val nombre: String?,
    val ubicacion: String?
)