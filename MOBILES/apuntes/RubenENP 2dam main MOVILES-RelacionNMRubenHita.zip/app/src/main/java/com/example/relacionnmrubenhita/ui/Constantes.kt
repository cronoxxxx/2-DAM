package com.example.relacionnmrubenhita.ui

object Constantes {
    const val CONSOLA = "Consolas"
    const val JUGADOR_ID = "jugadorId"
    const val ANYADIDO = " Añadido"
    const val CONSOLA_ID = "consolaId"
}