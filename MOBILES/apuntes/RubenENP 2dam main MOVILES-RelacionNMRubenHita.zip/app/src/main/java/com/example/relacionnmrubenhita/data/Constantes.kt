package com.example.relacionnmrubenhita.data

object Constantes {
    const val SELECT_CONSOLAS = "SELECT * FROM consolas"
    const val SELECT_JUGADORES = "SELECT * FROM jugadores"
    const val DB_RUTA = "database/consolas.db"
    const val ASSETDB = "assetDB"
    const val ITEMS = "items"
}