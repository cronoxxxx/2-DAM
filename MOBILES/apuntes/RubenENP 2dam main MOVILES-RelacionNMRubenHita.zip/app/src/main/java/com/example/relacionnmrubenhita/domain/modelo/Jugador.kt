package com.example.relacionnmrubenhita.domain.modelo

class Jugador (
    val id: Int,
    val nombre: String,
    val dinero: Int,
    val consolasList: List<Consola>,
)