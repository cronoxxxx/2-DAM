package com.example.finalexamenmoviles_adriansaavedra.data.remote.model

class Informe {
}