package com.example.finalexamenmoviles_adriansaavedra.data.remote.model

data class Raton(val nombre:String)