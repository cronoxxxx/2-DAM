package com.example.playersapp_adriansaavedra.data.remote.model

data class Register(val username: String = "", val password: String = "", val email: String = "")
