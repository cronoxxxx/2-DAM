package com.example.playersapp_adriansaavedra.data.remote.model

data class LoginUser(val username: String = "", val password: String = "")