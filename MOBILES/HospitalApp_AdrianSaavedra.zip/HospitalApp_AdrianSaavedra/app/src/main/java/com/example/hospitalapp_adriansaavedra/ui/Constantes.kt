package com.example.hospitalapp_adriansaavedra.ui

object Constantes {
    const val ERROR_API_CALL_FAILED = "Error API llamada fallida: "
}