package org.example.calculatorfxadriansaavedra;

public class Main {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
