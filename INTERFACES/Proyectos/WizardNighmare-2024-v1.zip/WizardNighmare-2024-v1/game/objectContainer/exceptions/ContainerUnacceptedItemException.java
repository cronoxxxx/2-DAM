package game.objectContainer.exceptions;

public class ContainerUnacceptedItemException extends Throwable {
}
