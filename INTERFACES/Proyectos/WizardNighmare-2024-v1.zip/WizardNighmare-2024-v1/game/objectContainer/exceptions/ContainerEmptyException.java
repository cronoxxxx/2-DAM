package game.objectContainer.exceptions;

public class ContainerEmptyException extends Throwable {
}
