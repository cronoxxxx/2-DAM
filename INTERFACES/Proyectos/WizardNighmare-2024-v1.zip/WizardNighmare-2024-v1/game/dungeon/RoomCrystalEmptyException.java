package game.dungeon;

public class RoomCrystalEmptyException extends Throwable {
}
