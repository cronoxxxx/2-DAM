package game.dungeon;

public class HomeNotEnoughSingaException extends Throwable {
}
