package game.demiurge.exceptions;

public class GoHomekException extends Throwable {
}
