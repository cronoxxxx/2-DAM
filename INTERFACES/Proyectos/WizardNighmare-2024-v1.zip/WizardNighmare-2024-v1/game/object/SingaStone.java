package game.object;

import game.Domain;

public class SingaStone extends Item{

    public SingaStone(int s, int m) {
        super(Domain.NONE, s, 0, m);
    }

}
