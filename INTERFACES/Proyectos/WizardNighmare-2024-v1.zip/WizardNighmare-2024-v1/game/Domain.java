package game;

public enum Domain {NONE, ELECTRICITY, AIR, FIRE, LIFE, ENERGY, JUMP}
