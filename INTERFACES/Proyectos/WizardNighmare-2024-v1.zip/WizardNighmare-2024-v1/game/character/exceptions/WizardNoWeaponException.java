package game.character.exceptions;

public class WizardNoWeaponException extends Throwable {
}
