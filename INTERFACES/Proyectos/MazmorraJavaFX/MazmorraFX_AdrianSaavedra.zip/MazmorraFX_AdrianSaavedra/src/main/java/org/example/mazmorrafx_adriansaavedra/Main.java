package org.example.mazmorrafx_adriansaavedra;

public class Main {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
